#ifndef _LINKEDLIST__H_
#define _LINKEDLIST__H_
#include"Node.h"
#include<ostream>
using namespace std;
class LinkedList
{
	Node *head;
	void deleteAllNodes();
public:
	LinkedList(); //default constructor
	LinkedList(int); //with one argument
	~LinkedList(); // delete all nodes
	void insert(int); //insert data from front
	void append(int); //insert data from last
	int DeleteFirst(); //delete data from first
	int DeleteLast(); //delete data from last
	void Display();
	//void LinkedList(LinkedList&);
	void operator=(LinkedList&);
	friend ostream& operator<<(ostream& out,LinkedList& x);
};

#endif
