#ifndef _NODE__H_
#define _NODE__H_
class Node
{
	int data;
	Node* next;
public:
	Node();
	~Node();
	Node(int,Node*);
	Node(int);
	Node(Node &x);
	void setNext(Node*);
	Node* getNext();
	void setData(int);
	int getData();
};

#endif
