#include<stdio.h>
#include<stdlib.h>
int f=-1,r=-1;

int size = 0;
int *arr;

void init()
{
	
	printf("size of queue : ");
	scanf("%d",&size);
	
	arr=(int*)malloc(size*sizeof(int));
}

void fini()
{
	free(arr);
}

void enqueue(int x)

{

	if(!(r==size-1))  // Check queue is empty??????
	{
		if(f==-1) // check  front is pointing on 
		{
			f++;
		}	
		r++;
		arr[r]=x;  //addin element into queue
	}
	else
	{
		printf("Queue is full \n");
	}

}

int dequeue()
{
	int temp;
	if(r==-1) //check rear pointing to the -1;
	{
		printf("\n Queue is empty \n");
	
		return -1;	
	}
	else
	{
		temp=arr[f]; //assigne front to the temp veriable 

		if(f!=r)	//check whether it is last element or not
		{
			f++;
		}				
		else
		{
			f=r=-1;
		}

	}
return temp;
}


void display()
{
	if(r==-1)
	{
		printf("\n Queue is empty \n");
	
	}
		else
	{
		int i=f;
		while(i<=r)
		{
			printf("%d ",arr[i]);
			i++;
			
		}
	}

}

int main()
{
	init();
	enqueue(10);
	enqueue(11);
	enqueue(12);
	enqueue(13);
	enqueue(14);
	enqueue(15);
	enqueue(16);
	enqueue(17);
	enqueue(18);
	enqueue(19);
	enqueue(20);
	enqueue(21);
	display();
	printf("\n");
	printf("%d ",dequeue());
	printf("%d ",dequeue());
	printf("%d ",dequeue());
	/*printf("%d ",dequeue());
	printf("%d ",dequeue());
	printf("%d ",dequeue());
	printf("%d ",dequeue());
	printf("%d ",dequeue());
	printf("%d ",dequeue());
	printf("%d ",dequeue());
	printf("%d ",dequeue());
	printf("%d ",dequeue());*/
	fini();
return 0;
}
