#include "Node.h"
#include<cstring>
Node::Node(Student x)
{
	data=x;
	next=NULL;
}

Node::Node(Student x,Node* ptr)
{
	data=x;
	next=ptr;
	
}
void Node:: setNext(Node* ptr)
{
	next=ptr;
	
}

Node* Node:: getNext()
{
	return next;
}

void Node:: setData(Student x)
{
	data=x;
}

Student Node::getData()
{
	return data;
}




