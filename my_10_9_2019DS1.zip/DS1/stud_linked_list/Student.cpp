#include"Student.h"
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<ostream>
#include<istream>
using namespace std;

Student::Student()
{
	name=new char[100];
	strcpy(name,"Nothing");
	pnr=0;

}

Student::Student(const char* c,int x)
{
	name=new char[strlen(c)+1];
	strcpy(name,c);
	pnr=x;

}

Student::Student(const Student& x)
{
	this->name = new char[strlen(x.name)+1];
	strcpy(this->name,x.name);
	this->pnr = x.pnr;

}
Student::~Student()
{
	//delete [] name;

}

ostream& operator<<(ostream& out,const Student& x)
{
	out<<x.name<<endl;
	out<<x.pnr<<endl;
	return out;
}

istream& operator>>(istream& in,Student& x)
{
	in>>x.name;
	in>>x.pnr;
	return in;
}
