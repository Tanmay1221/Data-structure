#ifndef _Student__H_
#define _Student__H_
#include<iostream>
#include<ostream>
#include<istream>
using namespace std;
class Student
{
	char *name;
	int pnr;
public:
	Student();
	Student(const char*,int);
	~Student();
	Student(const Student&);
	friend ostream& operator<<(ostream& out,const Student& x);
	friend istream& operator>>(istream& in,Student& x);
};
#endif
