#include "LinkedList.h"
#include "Node.h"
#include"Student.h"
#include<iostream>
using namespace std;

int main()
{
	LinkedList l1;
	Student s;
	cin>>s;
	l1.Insert(s);
	cout<<l1;
	
}
