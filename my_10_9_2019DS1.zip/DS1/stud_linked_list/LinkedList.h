#ifndef _LINKEDLIST__H_
#define _LINKEDLIST__H_
#include<ostream>
using namespace std;
#include "Node.h"
#include"Student.h"

class LinkedList
{
	Node *head;
public:
	LinkedList();
	~LinkedList();
	void Insert(const Student);
	void Append(const Student);
	Student deleteFirst();
	Student deleteLast();
	void display();
	void InsertByPosition(int,Student);
	Student DeleteByPosition(int);
	int CountNodes();
	LinkedList(const LinkedList &);
	void DeleteAll();
	void operator=(LinkedList &x);
	friend ostream& operator<<(ostream& out, LinkedList& x);

};
#endif
