#include<stdio.h>

void InsertionSort(int *arr,int size,int Type);
void SelectionSort(int *arr,int size,int Type);
void BubbleSort(int *arr,int size,int Type);
void swap(int *ar,int *tmp);
void Display(int *arr,int size);

/**********************main******************************/
int main()
{
	int arr[]={7,1,18,6,3,11,60};
	/*printf("****************Selection Sort********************\n");
	SelectionSort(arr,7,1);
	Display(arr,7);*/
/*	printf("****************Insertion Sort********************\n");
	InsertionSort(arr,7,0);
	Display(arr,7);*/
	printf("****************Bubble Sort********************\n");
	BubbleSort(arr,7,0);
	Display(arr,7);
}

/**********************selection sort********************/
void SelectionSort(int *arr,int size,int Type)
{
	int count=0;
	for(int i=0;i<size;i++)
	{
		int temp=arr[i];
		for(int j=i+1;j<size;j++)
		{
			count++;
			if(Type == 0)
			{
				if(temp>arr[j])
				{
					swap(&arr[j],&temp);
				}
			}
			else
			{
				if(temp<arr[j])
				{
					swap(&arr[j],&temp);
				}
			}
			
		}
	arr[i]=temp;
	}
	printf("%d\n",count);
}
/**********************Insertion sort********************/
void InsertionSort(int *arr,int size,int Type)
{
	int count=0;
	for(int i=1;i<size;i++)
	{
		int j = i;
		while(j>0)
		{
		count++;
			if(arr[j] < arr[j-1])
				swap(&arr[j],&arr[j-1]);
			else
				break;
			j--;
		}
	}
	printf("%d\n",count);
}

/********************Bubble Sort*************************/
void BubbleSort(int *arr,int size,int Type)
{
	int flag=0;
	for(int i=0;i<size-1;i++)
	{
		for(int j=0;j<size-1;j++)
		{
			if(Type == 0)
			{
				if(arr[j+1] < arr[j])
				{
					flag=1;
					swap(&arr[j+1],&arr[j]);
				}
			}
			else
			{
				if(arr[j+1] > arr[j])
				{
					flag=1;
					swap(&arr[j+1],&arr[j]);
				}
			}
		}
		if(flag==0)
			break;
		else
			flag=0;
	}
}
/**********************swap****************************/
void swap(int *ar,int *tmp)
{
	int temp = *ar;
	*ar = *tmp;
	*tmp = temp;
}

/**********************Display*************************/
void Display(int *arr,int size)
{
	for(int i=0;i<size-1;i++)
	{
		printf("%d->",arr[i]);
	}
	printf("%d\n",arr[size-1]);
}
