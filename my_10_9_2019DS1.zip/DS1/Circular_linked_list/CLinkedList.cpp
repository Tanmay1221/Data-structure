CLinkedList()
{

}

~CLinkedList()
{

}

CLinkedList(CLinkedList&)
{

}

void Insert(int d)
{

}

void Append(int d)
{

}

int DeleteFirst()
{

}

int DeleteLast()
{

}

int DeleteByPos(int pos)
{

}

void InsertByPos(int pos,int d)
{

}

