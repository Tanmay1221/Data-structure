#include"Node.h"
#include"iostream"
using namespace std;

Node::Node()
{
	data=0;
	Next=NULL;
}

Node::~Node()
{
	Next=NULL;
}

Node::Node(int val)
{
	data=val;
	Next=NULL;
}

Node::Node(int val,Node* ptr)
{
	data=val;
	Next=ptr;
}

Node* Node::getNext()
{
	return Next;
}

void Node::setNext(Node* ptr)
{
	Next=ptr;
}

int Node::getData()
{
	return data;
}

void Node::setData(int val)
{
	data=val;
}
