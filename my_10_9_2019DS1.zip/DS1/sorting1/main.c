#include<stdio.h>
int main()
{
	int arr1[] = {1,987,54,321,21,7,13,32};
	int arr2[] = {987,874,6,87,32,9,65,68};
	
	
}
