



for((x=0;x<=100;x++))
do
 echo "$x"
done
