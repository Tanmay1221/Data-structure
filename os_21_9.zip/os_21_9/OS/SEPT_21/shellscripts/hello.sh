
#!/bin/bash

echo -n "Hello World"  #this is a comment
			# -n means dont add new line

x=23
x="ppp"
y="cdac"
z=8.9

echo "x=$x y=$y z=$z" 


