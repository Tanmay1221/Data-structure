#include<stdio.h>
#include<stdlib.h>
int *arr;
int f=-1;
int r=-1,size;

void init()
{

	printf("Enter Queue Size  :");
	scanf("%d",&size);
	arr=(int*)malloc(size*sizeof(int));
}

int isFull()
{
	if(f==0 && r==size-1)
		return 1;
	else
		return 0;

}



int isEmpty()
{
	if(f==-1)
		return 1;
	else
		return 0;

}



void InsertFormR(int data)
{
	if(!isFull())
	{
		if(f==-1)  //Empty queue
		{
			r++;
			f++;
			arr[r]=data;
			return;
		}		
		
		else if(r<size)  // Inserting from rare end
		{
			r++;
			arr[r]=data;
			return;
		}

		else if(!f==0) // Queue empty from front side
		{
			f--;	
			int i=f;
			
			while(i<=r)
			{
				arr[i]=arr[i+1];
				i++;
			
			}
				arr[r]=data;
				return;

		}

		else
		{
			printf("OOOhhhh So Intelligent u R\n");
		}

	}

	else
	{
		printf("Queue is Full \n");
	}

}

void InsertFormF(int data)
{
		if(!isFull())
		{
			if(f==-1)  //Empty queue
			{
				r++;
				f++;
				arr[f]=data;
				return;
			}	
	
			else if(!f==0)
			{
				f--;
				arr[f]=data;
			}

			else if(r<size-1)
			{
				r++;
				int i=r;
				while(f<=i)
				{
					arr[i]=arr[i-1];
					i--;
				}
			}	
			else
			{
				printf("oops.......\n");
			}
		
		}
		else
		{
			printf("bro no entry");
		}

}

int RemoveFormR()
{
	if(!isEmpty())
	{
		int temp=arr[r];
		r--;
		return temp;		

	}
	else
	{
		printf("oohh my god queue is empty");
	}

}

int RemoveFormF()
{
		if(!isEmpty())
		{
			int temp=arr[f];
			if(f!=r)
				f++;
			else
			{
				f=-1;
				r=-1;
			}
		}
		else
		{
			printf("Queue is empty  \n");
		}


}

void display()
{

	if(!isEmpty())
	{
		int i=f;
		while(i<=r)
		{
			printf("%d  ,",arr[i]);
			i++;
		}
		printf("\n");
	}

}


int enterElement()
{
	int n;
	printf("Enter Number ");
	scanf("%d",&n);
	return n;
}


void fini()
{

	free(arr);

}


int main()
{
	int ch;
	init();
	while(1)
	{
		printf("==========Menu Card=============\n");
		printf("1. Insert Element Form Front \n");  
		printf("2. Insert Element Form Rear \n");  
		printf("3. Remove Element Form Front \n");   
		printf("4. Remove Element Form Rear  \n");
		printf("5. Display Queue \n");  
		printf("6. Exit\n");
		printf("================================\n");
		printf("Enter Ur Choice :  ");
		scanf("%d",&ch);

		switch(ch)
		{
			case 1:
				//enterElement();
				InsertFormF(enterElement());
				break;
			case 2:
				InsertFormR(enterElement());
				break;
			case 3:
				RemoveFormF();
				break;
			case 4:
				RemoveFormR();
				break;
			case 5:
				display();
				break;
			case 6:
				return 0;
			default:
				printf("first read instructions\nthen choose options\n");
		}


	}
	
	fini();
	
	
	


}
