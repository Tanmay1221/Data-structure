#include"Node.h"

Node::Node()
{
	Prev=NULL;
	Data = 0;
	Next = NULL;
}

Node::~Node()
{

}

Node::Node(int d)
{
	Prev = NULL;
	Data = d;
	Next = NULL;
}

Node::Node(Node* p,int d,Node* n)
{
	Prev = p;
	Data = d;
	Next = n;
}

Node* Node::getPrev()
{
	return Prev;
}

void Node::setPrev(Node* p)
{
	Prev =p;
}

Node* Node::getNext()
{
	return Next;
}

void Node::setNext(Node* n)
{
	Next=n;
}

int Node::getData()
{
	return Data;
}

void Node::setData(int d)
{
	Data = d;
}

