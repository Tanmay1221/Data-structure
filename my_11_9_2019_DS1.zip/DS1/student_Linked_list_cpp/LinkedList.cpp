#include"LinkedList.h"
#include"Node.h"
#include"iostream"
using namespace std;

LinkedList::LinkedList()
{
	head=NULL;
}
LinkedList::~LinkedList()
{
	head=NULL;
}
LinkedList::LinkedList(int startValue)
{
	Node *tmp = new Node(startValue);
	tmp->setNext(NULL);
}

LinkedList::LinkedList(LinkedList& x)
{
	//LinkedList l2(l1);
	//this l2
	//x l1
	this->head = NULL;
	Node *it = x.head;
	while(it!=NULL)
	{
		this->append(it->getData());
		it = it->getNext();
	} 	
}

int LinkedList::getNumberOfNodes()
{
	int count=0;
	Node *it = head;
	while(it!=NULL)
	{
		count++;
		it = it->getNext();
	}
cout<<count<<endl;
return count;
}

void LinkedList::Insert(int val)
{	
		Node *tmp = new Node(val,head);
		head = tmp;	
}
void LinkedList::append(int val)
{
	if(head==NULL)
	{
		Insert(val);
		return;
	}
	Node *tmp = new Node(val);
	Node *it = head;
	while(it->getNext()!=NULL)
	{
		it=it->getNext();
	}
	it->setNext(tmp);
	
}
void LinkedList::InsertByPosition(int pos,int val)
{
	if(head!=NULL)
	{
		int count = getNumberOfNodes();
		if(pos == 1)
			Insert(val);
		if(count == pos-1)
			append(val);
		if(pos>count || pos<1)
			cout<<"Wrong position enterd"<<endl;
		else
		{
			Node *it = head;
			for(int i=1;i<pos-1;i++)
				it=it->getNext();
			Node *tmp = new Node(val);
			tmp->setNext(it->getNext());
			it->setNext(tmp);
		}		
	}
	else
	{
		cout<<"Linked List is Empty"<<endl;
	}	
}
void LinkedList::DeleteFirst()
{
	
	if(head != NULL)
	{
		Node *it = head;	
		head = head->getNext();
		free(it);
	}
	else
		cout<<"Empty Linked List"<<endl;	
}
void LinkedList::DeleteLast()
{
	if(head !=NULL)
	{
		Node *it = head;
		if(it->getNext() == NULL)
		{
			DeleteFirst();
			return;
		}	
		while(it->getNext()->getNext()!=NULL)
		{
			it = it->getNext();
		}
		free(it->getNext()->getNext());
		it->setNext(NULL);		
	}
	else
	{
		cout<<"Empty Linked List"<<endl;
	}
}
void LinkedList::DeleteByPosition(int pos)
{
	
	if(head!=NULL)
	{
		int count = getNumberOfNodes();
		if(pos == 1)
			DeleteFirst();
		if(count == pos-1)
			DeleteLast();
		if(pos>count || pos<1)
			cout<<"Wrong position enterd"<<endl;
		else
		{
			Node *it = head;
			for(int i=1;i<pos-1;i++)
				it=it->getNext();
			cout<<it->getData()<<endl;
			Node *tmp = it->getNext();
			it->setNext(tmp->getNext());
			tmp->setNext(NULL);
			delete tmp;
		}		
	}
	else
	{
		cout<<"Linked List is Empty"<<endl;
	}
		
}
void LinkedList::Display()
{
	if(head != NULL)
	{
		Node *it = head;
		while(it != NULL)
		{
			cout<<it->getData()<<"=>";
			it = it->getNext();		
		}
		cout<<endl;		
	}
	else
	{
		cout<<"Linked List is empty"<<endl;
	}
}
