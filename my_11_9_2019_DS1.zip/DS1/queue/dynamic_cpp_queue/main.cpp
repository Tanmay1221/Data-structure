#include"Queue.h"

int main()
{
	Queue q;
	q.enqueue(10);
	q.enqueue(20);
	q.enqueue(30);
	q.enqueue(40);
	q.enqueue(50);
	q.enqueue(60);
	q.display();
	cout<<endl;
	q.dequeue();
	q.dequeue();
	q.dequeue();
	q.dequeue();
	q.display();
	
return 0;
}
