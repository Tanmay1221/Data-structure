#include"Queue.h"
Queue::Queue()
{
	f=-1,r=-1;
	cout<<"size of queue : "<<endl;
	cin>>size;
	//arr=(int*)malloc(size*sizeof(int));
	arr = new int[size];

}
Queue::~Queue()
{
	f=-1,r=-1;
	delete [] arr;
}
void Queue::enqueue(int x)
{
	if(!(r==size-1))  // Check queue is empty??????
	{
		if(f==-1) // check  front is pointing on 
		{
			f++;
		}	
		r++;
		arr[r]=x;  //addin element into queue
	}
	else
	{
		cout<<"Queue is full"<<endl;
	}
}
int Queue::dequeue()
{
	
	int temp;
	if(r==-1) //check rear pointing to the -1;
	{
		cout<<"Queue is empty"<<endl;
	
		return -1;	
	}
	else
	{
		temp=arr[f]; //assigne front to the temp veriable 

		if(f!=r)	//check whether it is last element or not
		{
			f++;
		}				
		else
		{
			f=r=-1;
		}

	}
return temp;

}
void Queue::display()
{
	if(r==-1)
	{
		cout<<"Queue is empty"<<endl;
	
	}
		else
	{
		int i=f;
		while(i<=r)
		{
			cout<<arr[i]<<" , ";
			i++;
			
		}
	}
}
