#include<stdio.h>


void swap(int *tmp,int *arr1)
{
	int temp=*arr1;
	*arr1=*tmp;
	*tmp=temp;
	

}


void selectionSort(int *arr1,int size)
{
	for(int i=0;i<size;i++)
	{	
		int temp=arr1[i];
		for(int j=i+1;j<size;j++)
		{
			if(temp>arr1[j])
				swap(&temp,&arr1[j]);
		}
		arr1[i]=temp;		
	}
	

}




void display(int *arr,int size)
{
	for(int i=0;i<size-1;i++)
	{
		printf("[%d]👉",arr[i]);
	}
	printf("[%d]\n",arr[size-1]);

}

void Merge(int *arr1,int *arr2,int *arr3,int size)
{
	int k=0;
	for(int i=0;i<size;)
	{
		for(int j=0;j<size;)
		{
			if(arr1[i]>arr2[j])
			{
				arr3[k]=arr2[j];
				k++;
				j++;	
			}
			else
			{
				arr3[k]=arr1[i];
				k++;
				i++;
			}
		}	
	}

}




int main()
{
	int arr1[] = {1,987,54,321,27};
	int arr2[] = {989,874,6,322,32};
	int arr3[11];

	selectionSort(arr1,5);
	display(arr1,5);
	selectionSort(arr2,5);
	display(arr2,5);
	Merge(arr1,arr2,arr3,5);
	display(arr3,11);
	
	
	
}
