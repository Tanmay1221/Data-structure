#include "DQueue.h"
DQueue::DQueue()
{
	cout<<"Enter Queue Size  :";
	cin>>size;
	arr=new int[size];

}
DQueue::~DQueue()
{
	delete [] arr;
}

void DQueue::InsertFormF(int data)
{

		if(!isFull())
		{
			if(f==-1)  //Empty queue
			{
				r++;
				f++;
				arr[f]=data;
				return;
			}	
	
			else if(!f==0)
			{
				f--;
				arr[f]=data;
			}

			else if(r<size-1)
			{
				r++;
				int i=r;
				while(f<=i)
				{
					arr[i]=arr[i-1];
					i--;
				}
			}	
			else
			{
				cout<<"oops......."<<endl;
			}
		
		}
		else
		{
			cout<<"bro no entry"<<endl;
		}


}
int DQueue::enterElement()
{
	int n;
	cout<<"Enter Number ";
	cin>>n;
	return n;

}



void DQueue::InsertFormR(int data)
{
	if(!isFull())
	{
		if(f==-1)  //Empty queue
		{
			r++;
			f++;
			arr[r]=data;
			return;
		}		
		
		else if(r<size)  // Inserting from rare end
		{
			r++;
			arr[r]=data;
			return;
		}

		else if(!f==0) // Queue empty from front side
		{
			f--;	
			int i=f;
			
			while(i<=r)
			{
				arr[i]=arr[i+1];
				i++;
			
			}
				arr[r]=data;
				return;

		}

		else
		{
			cout<<"OOOhhhh So Intelligent u R"<<endl;
		}

	}

	else
	{
		cout<<"Queue is Full "<<endl;
	}


}
int DQueue::RemoveFormF()
{
	if(!isEmpty())
		{
			int temp=arr[f];
			if(f!=r)
				f++;
			else
			{
				f=-1;
				r=-1;
			}
		}
		else
		{
			cout<<"Queue is empty "<<endl;
		}

}
int DQueue::RemoveFormR()
{

	if(!isEmpty())
	{
		int temp=arr[r];
		r--;
		return temp;		

	}
	else
	{
		cout<<"oohh my god queue is empty"<<endl;
	}


}



int DQueue::isFull()
{
	if(f==0 && r==size-1)
		return 1;
	else
		return 0;

}



int DQueue::isEmpty()
{
	if(f==-1)
		return 1;
	else
		return 0;

}


void DQueue::display()
{
	if(!isEmpty())
	{
		int i=f;
		while(i<=r)
		{
			cout<<arr[i];
			i++;
		}
		cout<<endl;
	}
	else
	{
		cout<<"Queue is Empty"<<endl;
	}


}
