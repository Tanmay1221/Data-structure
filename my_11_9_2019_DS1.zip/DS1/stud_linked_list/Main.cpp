#include "LinkedList.h"
#include "Node.h"
#include"Student.h"
#include<iostream>
using namespace std;

int main()
{
	LinkedList l1;	
	Student s;
	int n;	
	cout<<"Number of students : ";
	cin>>n;
	
	while(n--)
	{
		cout<<"Enter name and prn"<<endl;
		cin>>s;
		l1.Append(s);
	}
	
	cout<<"=============================================="<<endl;
	cout<<l1;
	cout<<"=============================================="<<endl; 
	l1.selectionSort();	
	cout<<l1;	
	
}
