#include<stdio.h>
int main()
{
	int n;
	printf("test case : ");
	scanf("%d",&n);
	while(n--)
	{
		char S1[100];
		char S2[100];
		printf("String");
		scanf("%c %c",S1,S2);
	}
}
