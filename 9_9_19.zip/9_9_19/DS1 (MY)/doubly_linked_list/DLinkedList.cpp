#include"DLinkedList.h"
DLinkedList::DLinkedList()
{
	head = NULL;
	tail = NULL;
}

DLinkedList::~DLinkedList()
{

}

void DLinkedList::Insert(int d)
{
	Node *temp = new Node(d);
	if(head==NULL)
	{
		head=tail=temp;
		return;
	}
	temp->setNext(head);
	head->setPrev(temp);
	head = temp;
}

void DLinkedList::Append(int d)
{
	Node *temp = new Node(d);
	if(head==NULL)
	{
		head=tail=temp;
		return;
	}
	tail->setNext(temp);
	temp->setPrev(tail);
	tail = temp;
}

int DLinkedList::DeleteFirst()
{
	if(head==tail)
	{
		delete head;
		head=tail=NULL;
	}
	else
	{
		Node* temp = head;
		head = temp->getNext();
		head->setPrev(NULL);
		delete temp;
	}
}

int DLinkedList::DeleteLast()
{
	if(head==tail)
	{
		delete head;
		head=tail=NULL;
	}
	else
	{
		Node* it= tail->getPrev();
		tail->setPrev(NULL);
		it->setNext(NULL);
		delete tail;
		tail=it;
	}	
}

void DLinkedList::InsertByPosition(int,int)
{

}

int DLinkedList::DeleteByPosition(int)
{

}

void DLinkedList::Display()
{
	if(head!=NULL)
	{
		Node *it = head;
		while(it->getNext()!=NULL)
		{
			cout<<it->getData()<<"=>";
			it=it->getNext();
		}
		cout<<it->getData()<<endl;
	}
	else
	{
		cout<<"DLL is empty"<<endl;
	}
}

