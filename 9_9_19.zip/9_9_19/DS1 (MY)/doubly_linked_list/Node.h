#ifndef _NODE__H_
#define _NODE__H_
#include<iostream>
using namespace std;
class Node
{
	Node* Prev;
	int Data;
	Node* Next;
public:
	Node();
	~Node();
	Node(int);
	Node(Node*,int,Node*);
	Node* getPrev();
	void setPrev(Node*);
	Node* getNext();
	void setNext(Node*);
	int getData();
	void setData(int);
	
};
#endif
