#ifndef _DLINKEDLIST__H_
#define _DLINKEDLIST__H_
#include"Node.h"
#include<iostream>
using namespace std;

class DLinkedList
{
	Node* head;
	Node* tail;
public:
	DLinkedList();
	~DLinkedList();
	
	void Insert(int);
	void Append(int);
	int DeleteFirst();
	int DeleteLast();
	void InsertByPosition(int,int);
	int DeleteByPosition(int);
	
	void Display();	
};
#endif
