#include<stdio.h>
#include<stdlib.h>

typedef struct node
{
	struct node *next;
	int data;
	
}Node;

Node *head=NULL;


int EnterNumber()
{
	int n;
	printf("Enter Number  :");
	scanf("%d",&n);
	return n;
	 
}

int EnterPosition()
{
	int n;
	printf("Enter Position  :");
	scanf("%d",&n);
	return n;
	 
}

int getNoOfNodes()
{
	int count = 0;
	if(head == NULL)
		return 0;
	Node *it = head;
	while(it!=NULL)
	{
		it=it->next;
		count++;
	}
//printf("%d\n",count);
return count;
}

void Insert(int data)
{
	Node *temp=(Node*)malloc(sizeof(Node));
	temp->data=data;
	temp->next=NULL;

	if(head==NULL)
	{
		head=temp;
		return;
	}
	temp->next=head;
	head=temp;	
}

void Append(int data)
{
	Node *temp=(Node*)malloc(sizeof(Node));
	temp->data=data;
	temp->next=NULL;
	if(head==NULL)
	{
		head=temp;
		return;
	}

	Node *it=head;
	if(head!=NULL)
	{
		while(it->next!= NULL)
		{
			it=it->next;
			
		}
		it->next=temp;
	}	
}

int DeleteFirst()
{
	Node *it=head;
	if(head!=NULL)
	{
		head=it->next;
//		it->next=NULL;	
		free(it);

	}
	else
	{
		printf("LL is Empty");
	}
}



int DeleteLast()
{
	Node *it=head;
	if(head!=NULL)
	{
		while(it->next->next!=NULL)
		{
			it=it->next;

		}		
		free(it->next);
		it->next=NULL;
	}
}

void display()
{
	Node *it=head;
	if(head!=NULL)
	{
		while(it->next!= NULL)
		{
			printf("[%d]==>",it->data);
			it=it->next;
		}
		printf("[%d]",it->data);
		printf("\n");
	}
	else
		printf("Linked List Is Empty");
}

void InsertOnPosition(int data,int pos)
{
	int count = getNoOfNodes();
	if(pos == 1)
		Insert(data);
	if(pos == count+1)
		Append(data);
	if(pos>count && pos<1)
		printf("God will help you !!");
	else
	{
		Node *it = head;
		Node *temp = (Node*)malloc(sizeof(Node));
		temp->data = data;
		temp->next = NULL;
		
		int x=1;
		while(x!=pos-1)
		{
			it=it->next;
			x++;
		}
		temp->next=it->next;
		it->next=temp;
	}
}

void DeleteFromPosition(int pos)
{
	int count = getNoOfNodes();
	if(pos == 1)
		DeleteFirst();
	if(pos == count+1)
		DeleteLast();
	if(pos>count && pos<1)
		printf("God will help you !!");
	else
	{
		Node* it=head;
		for(int i=1;i<pos-1;i++,it=it->next);
		//Node *temp=it->next;
		//it->next=temp->next;
		//free(temp);	 
		
		Node* itn = it->next;
		it->next = it->next->next;
		itn->next = NULL;
		free(itn);
	}
}


/*void reverse()
{
	
}
*/

int main()
{
	while(1)
	{
		system("clear");
		int ch;
		printf("😋 =============Menu Card================ 😋\n");
		printf("👉 1. Insert Element From Front\n");
		printf("👉 2. Insert Element From End\n");
		printf("👉 3. Insert Element In Given Position\n");
		printf("👉 4. Delete Element From Front\n");
		printf("👉 5. Delete Element From End\n");
		printf("👉 6. Delete Element From Given Position\n");
		printf("👉 7. Display\n");
		printf("👉 8. Exit\n");
		printf("😋 ====================================== 😋\n");

		printf("Enter choice : ");
		scanf("%d",&ch);
		switch(ch)
		{
			case 1: 
				Insert(EnterNumber());
				break;
			case 2: 
				Append(EnterNumber());
				break;
			case 3: 
				InsertOnPosition(EnterNumber(),EnterPosition());
				break;
			case 4: 
				DeleteFirst();
				break;
			case 5: 
				DeleteLast();
				break;
			case 6: 
				DeleteFromPosition(EnterPosition());
				break;
			case 7: 
				display();
				printf("Enter 0 to reset\n");
				int m;
				scanf("%d",&m);
				break;
			case 8: 
				return 0;
				break;
			default:
				printf("u r wrong person to handle this system.\n");
				int n;
				scanf("%d",&n);				
				break;
		}
	}
} 













