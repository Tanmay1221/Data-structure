#include "DQueue.h"
int main()
{
	int ch;
	DQueue dq;
	while(1)
	{
		cout<<"==========Menu Card============="<<endl;
		cout<<" 1. Insert Element Form Front "<<endl;  
		cout<<" 2. Insert Element Form Rear "<<endl;  
		cout<<" 3. Remove Element Form Front "<<endl;   
		cout<<" 4. Remove Element Form Rear "<<endl;
		cout<<" 5. Display Queue "<<endl;  
		cout<<" 6. Exit"<<endl;
		cout<<"================================"<<endl;
		cout<<"Enter Ur Choice :  ";
		cin>>ch;

		switch(ch)
		{
			case 1:
				//enterElement();
				dq.InsertFormF(dq.enterElement());
				break;
			case 2:
				dq.InsertFormR(dq.enterElement());
				break;
			case 3:
				dq.RemoveFormF();
				break;
			case 4:
				dq.RemoveFormR();
				break;
			case 5:
				dq.display();
				break;
			case 6:
				return 0;
			default:
				cout<<"first read instructions\nthen choose options"<<endl;
		}


	}
	
		
	
	


}
