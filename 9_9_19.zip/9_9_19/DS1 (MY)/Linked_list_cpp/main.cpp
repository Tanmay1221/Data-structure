
#include<iostream>
using namespace std;
#include"LinkedList.h"
#include"Node.h"

int main()
{

	LinkedList l1;
	l1.insert(10);
cout<<l1;
	l1.insert(20);
cout<<l1;
	l1.DeleteLast();
cout<<l1;
	l1.insert(30);
cout<<l1;
	l1.DeleteFirst();
cout<<l1;
	l1.insert(40);
cout<<l1;
	l1.insert(50);
cout<<l1;
	l1.DeleteLast();
cout<<l1;
	LinkedList l2;	
	l2=l1;
cout<<l2;
	
}
