#ifndef _NODE__H_
#define _NODE__H_
#include<iostream>
using namespace std;
#include"Student.h"

class Node
{
	Node *next;
	Student data;
public:
	Node(Student);
	Node(Student,Node*);
	void setNext(Node* ptr);
	 Node* getNext();
	Student getData();
	void setData(Student);
	

};
#endif
