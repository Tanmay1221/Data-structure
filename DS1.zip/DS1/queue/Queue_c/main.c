#include<stdio.h>
#define SIZE 10	
int arr[SIZE];
int f=-1;
int r=-1;




void display()
{
	int i;
	if(f==-1)
	{
		printf("Queue is Empty\n");
	}
	else
	{	
		for(i=f;i<=r;i++)
		{
			printf("%d<--",arr[i]);
		}
		printf("\n");
	}
}

void enqueue(int data)
{
	if(r==SIZE-1)
	{
		printf("Queue is Full\n");	
	}
	else
	{		
		if(f==-1)
		{
			f++;
		}
		r++;
		arr[r]=data;
		//display();	
	}
}

void dequeue()
{
	if(f==-1)
	{
		printf("Queue is Empty\n");
	}
	else
	{	
		int temp=arr[f];	
		f++;
		//printf("%d\n",f);
	}	
}


int main()
{		
	enqueue(10);
	enqueue(20);
	enqueue(30);
	enqueue(40);

	display();
	
	dequeue();
	display();

	dequeue();
	display();

	return 0;
}
