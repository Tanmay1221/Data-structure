#include "stack.h"
#include <iostream>
using namespace std;

int main()
{

	Stack s1;
	s1.push(10);
	s1.push(20);
	s1.push(11);
	s1.push(91);
	s1.pop();
	
	return 0;

}


