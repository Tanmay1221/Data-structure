#include"Linklist.h"

Linklist::Linklist()
{
	head=NULL;
}

Linklist::~Linklist()
{
	
}

int Linklist::insert(Student data)
{
	Node *temp=new Node(data,head);
	head=temp;

}

void Linklist::append(Student data)		//insert from last
{
	Node *temp=new Node(data,NULL);
	
	if(head==NULL)	//LL is empty
	{
		head=temp;
		return;
	}
	
	Node *it=head;
	while(it->getnext()!=NULL)
	{
		
		it=it->getnext();
		
	}
	it->setnext(temp);
	

}

void Linklist:: insertatpos(Student a,const int pos)
{
	int noofnodes=count();
	if(pos==1)		//insert at first position
	{
		insert(a);
		
	}		
	else if(pos==noofnodes+1)	//insert at last position
	{
		append(a);
	}
	else if(pos<1 || pos>noofnodes+1)	//insert out of range position
	{
		cout<<"Position is out of range";
	}
	else
	{
		Node *temp=new Node(a);
	
		
		Node *it=head;
		int x=1;
		while(x!=pos-1)
		{
			it=it->getnext();
			x++;

		}
		temp->setnext(it->getnext());
		it->setnext(temp);
	}
}


void Linklist::deleteF()		//delete from front
{
	if(head !=NULL)
	{
		Node *ipt=head;
		head=ipt->getnext();
		delete(ipt);

	}

}

void Linklist::deleteL()			//delete from Last
{
	if(head->getnext()==NULL)
	{
		Node *it=head;
		head=NULL;
		delete(it);
		cout<<"Empty LL";
		return;
	}

	Node *it=head;
	while(it->getnext()->getnext()!=NULL)
	{
		it=it->getnext();
	}
	Node *temp=it->getnext();

	it->setnext(NULL);
	delete(temp);

}

Linklist::Linklist(Student startvalue)
{
	
	Node *tmp=new Node(startvalue);
	head=tmp;
}

int Linklist::count()
{
	int count=0;
	Node *it=head;
	while(it!=NULL)
	{
		
		count++;	
		it=it->getnext();
		
	}
	cout<<count<<endl;
	return count;

}
	
void Linklist::display()
{
	Node *it=head;
	while(it!=NULL)
	{
		cout<<"->"<<it->getdata();
		it=it->getnext();
		
	}
	cout<<"\n";

}



void Linklist::operator=(Linklist &d)
{
	//l2=l1
	//this >> l2
	//d >> l1
	this->deleteAllNodes();
	Node *it = d.head;
	while(it != NULL)	
	{
		this->append(it->getdata());
		it=it->getnext();

	}
}

void Linklist::deleteAllNodes()
{
	while(head != NULL)
	{
		Node *it = head;
		head = it->getnext();
		delete it;
	}
}


ostream& operator<<(ostream& out, Linklist& d)
{
	//empty???
	if(d.head == NULL)
	{
		out<<"LL is empty...\n"<<endl;
		return out;
	}

	//go to last node...
	Node *it=d.head;
	while(it!= NULL)
	{
		out<<it->getdata()<<"-->";
		it=it->getnext();


	}
	return out;
}


