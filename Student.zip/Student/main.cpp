#include<iostream>
#include"Linklist.h"

int main()
{
	Linklist l;
	Student s;
	cin>>s;
	l.insert(s);
	cin>>s;
	l.insert(s);
	cout<<l<<endl;
	cin>>s;
	l.append(s);	
	cout<<l<<endl;
	cin>>s;
	l.insertatpos(s,2);
	cout<<l<<endl;
	l.count();
	l.deleteF();
	cout<<l<<endl;	
	l.deleteL();
	cout<<l<<endl;
	Linklist l1(l);	
	cout<<l1<<endl;
	
}
