#include<iostream>
using namespace std;

#ifndef _NODE__H_
#define _NODE__H_
#include"Student.h"
class Node
{
	Student data;
	Node *next;

public:
	Node();
	Node(Student );
	Node(Student, Node* );
	~Node();
	Student getdata();
	void setdata(Student d);
	void operator=(Node &);
	Node* getnext();
	void setnext(Node*);
	
		

};

#endif
