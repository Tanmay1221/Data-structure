#include"Node.h"
Node::Node()
{
	
	next=NULL;
}

Node::Node(Student x)
{
	data=x;
	next=NULL;
}

Node::Node(Student x, Node* ptr)
{
	data=x;
	next=ptr;
}

Node::~Node()
{
	next=NULL;
	
}

Node* Node::getnext()
{
	return next;
}

void Node::setnext(Node* x)
{
	next=x;
	
}

Student Node::getdata()
{
	return data;

}

void Node::setdata(Student d)
{
	data=d;
}

void Node::operator=(Node& d)		
{
	this->data=d.data;
	this->next=NULL;

}
