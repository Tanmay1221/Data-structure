#include<cstdio>

#include"Student.h"
#include<cstring>
Student::Student()
{
	
	this->name= new char[10];
	strcpy(this->name,"unknown");
	rollno=-1;	
}
Student::~Student()
{
	delete []name;
}

Student::Student(const char *str,int x )
{
	this->name= new char[strlen(str)+10];
	strcpy(this->name,str);
	rollno=x;
}

Student::Student(const Student& x)
{
	this->name= new char[strlen(x.name)+10];
	strcpy(this->name,x.name);
	this->rollno=x.rollno;
}

void Student::operator=(Student& x)
{
	this->name= new char[strlen(x.name)+10];
	strcpy(this->name,x.name);
	this->rollno=x.rollno;

}
istream& operator>>(istream& in,Student& x)
{
	in>>x.name;
	in>>x.rollno;
	return in;
}
ostream& operator<<(ostream& out,const Student& x)
{
	out<<x.name;
	out<<x.rollno;
	return out;

}
