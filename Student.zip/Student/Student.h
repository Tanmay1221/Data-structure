#include<iostream>
using namespace std;
#ifndef _STUDENT__H_
#define _STUDENT__H_

class Student
{
	char *name;
	int rollno;

public :
	Student();
	Student(const Student&);
	Student(const char *str ,int x );
	~Student();
	/*char* getName();
	void setName(char* );
	int getRollno();
	void setRollno(int );*/
	void operator=(Student&);
	friend istream& operator>>(istream&,Student&);
	friend ostream& operator<<(ostream&,const Student&);
	
};

#endif
