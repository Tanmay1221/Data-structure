

#ifndef _LIINKLIST__H_
#define _LIINKLIST__H_
#include"Node.h"

class Linklist
{
	Node *head;

public:
	Linklist();
	~Linklist();
	Linklist(Student startvalue);
	int insert(Student);
	void append(Student);
	void insertatpos(Student,const int );
	void operator=(Linklist &);
	int count();
	void deleteF();
	void deleteL();
	void deleteAllNodes();
	void display();
	friend ostream& operator<<(ostream&, Linklist&);
	

};

#endif
