#ifndef _QUEUE__H_
#define _QUEUE__H_
#include<iostream>
using namespace std;

class Queue
{
	int *arr;
	int r;
	int f;
	int size;

public:
	Queue();
	~Queue();
	void enqueue(int );
	int dequeue();
	void display();
	
};
#endif
