#ifndef _DQUEUE__H_
#define _DQUEUE__H_
#include<iostream>
#include<cstdlib>
using namespace std;
class DQueue
{

	int *arr;
	int f=-1;
	int r=-1,size;

public:
	DQueue();
	~DQueue();
	void InsertFormF(int);
	int enterElement();
	void InsertFormR(int);
	int RemoveFormF();
	int RemoveFormR();
	int isFull();
	int isEmpty();
	void display();
};
#endif
