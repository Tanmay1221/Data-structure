//default constructor
#include<iostream>
#include<ostream>
using namespace std;
#include "LinkedList.h"

LinkedList::LinkedList()
{
	head = NULL;
} 

//with one argument
LinkedList::LinkedList(int d)
{
	Node *temp = new Node(d);
	head = temp;
} 

// delete all nodes
LinkedList::~LinkedList()
{
	deleteAllNodes();
} 

//insert data from front
void LinkedList::insert(int data)
{
	Node *tmp =new Node(data,head);
	head=tmp;
} 

//insert data from last
void LinkedList::append(int data)
{
	Node *tmp =new Node(data);
	//first Node???
	if(head == NULL)
	{
		head=tmp;
		return;
	}

	Node *it=head;
	while(it->getNext() != NULL)
	{
		it=it->getNext();
	}
	it->setNext(tmp);
} 

//delete data from first
int LinkedList::DeleteFirst()
{
	//do we have something to delete??
	if(head != NULL)
	{
		Node *tmp=head;
		head=tmp->getNext();
		delete tmp;		
	}
}

//delete data from last 
int LinkedList::DeleteLast()
{
	//do we have something to delete??
	if(head != NULL)
	{
		//only one node in LL??
		if(head->getNext() == NULL)
		{
			Node *tmp=head;
			head=NULL;
			delete tmp;
		}
		// ohhhhhhhh we have more than 1 node
		else
		{
			//go to last but one node...
			Node *it=head;
			while(it->getNext()->getNext() != NULL)
			{
				it=it->getNext();
			}
			Node *tmp =it->getNext();
			it->setNext(NULL);
			delete tmp;
		}
	}
} 
/*
//display function
void LinkedList::Display()
{
	//empty???
	if(head == NULL)
	{
		cout<<"LL is empty..."<<endl;
		return;
	}

	//go to last node...
	Node *it=head;
	while(it!= NULL)
	{
		cout<<it->getData()<<"-->";
		it=it->getNext();
	}
	cout<<endl;
}
*/

void LinkedList::deleteAllNodes()
{
	while(head != NULL)
	{
		Node *it = head;
		head = it->getNext();
		delete it;
	}
}

ostream& operator<<(ostream& out,LinkedList& x)
{
	if(x.head == NULL)
	{
		out<<"LL is empty..."<<endl;
		return out;
	}

	//go to last node...
	Node *it=x.head;
	while(it->getNext()!= NULL)
	{
		out<<"["<<it->getData()<<"]"<<" 👉 ";
		it=it->getNext();
	}
	out<<"["<<it->getData()<<"]"<<endl;
return out;
}
//copy constructor
LinkedList::LinkedList(LinkedList& x)
{
	this->head=NULL;
	Node *it = x.head;
	while(it != NULL)	
	{
		this->append(it->getData());
		it=it->getNext();
	}
}

void LinkedList::operator=(LinkedList& x)
{
	this->deleteAllNodes();
	Node *it = x.head;
	while(it != NULL)	
	{
		this->append(it->getData());
		it=it->getNext();
	}
}

//selection sort

void LinkedList::selectionSort()
{
	int c = NoOfNodes();
	if(head!=NULL)
	{	
		
		Node *it= head;
		while(it!=NULL)
		{
		Node *itn = it->getNext();
		while(itn!=NULL)
		{
			if(it->getData() > itn->getData())
			{
				Node* temp = new Node();
				temp->setData(it->getData());
				it->setData(itn->getData());
				itn->setData(temp->getData());
			}
			itn=itn->getNext();
		}
		it=it->getNext();
		}
	}

}

int LinkedList::NoOfNodes()
{
	int count=0;
	Node *it = head;
	while(it!=NULL)
	{
		count++;
		it=it->getNext();
	}
return count;
}	

int LinkedList::DeleteByPos(int pos)
{
	if(head!=NULL)
	{
		int c = NoOfNodes();
		if(pos == 1)
			DeleteFirst();
		if(pos == c-1)
			DeleteLast();
		if(pos<1 && pos>c)
			cout<<"Ganpati bappa morya....🚩"<<endl;
		else
		{
			Node *it = head;
			for(int i=1;i<pos-1;i++,it=it->getNext());
			Node *temp=it->getNext();
			it->setNext(temp->getNext());
			delete temp;
		}		

	}
	else
	{
		cout<<"you are not able to handle the system"<<endl;
	}
}
