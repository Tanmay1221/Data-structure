#include<iostream>
using namespace std;
#include "Node.h"

Node::Node()
{
	data=0;
	next=NULL;
}

Node::Node(int d)
{
	this->data=d;
	this->next=NULL;
}

//distructor
Node::~Node()
{
	 next = NULL;
}

//node with two argument
Node::Node(int data,Node* ptr)
{	
	this->data = data;
	this->next = ptr;	
}


Node::Node(Node &x)
{	
	this->data=x.data;
	this->next=NULL;
}

//setNext -> setter
void Node::setNext(Node* ptr)
{
	next = ptr;
}

//getNext -> getter
Node* Node::getNext()
{
	return next;
}

//setData -> setter
void Node::setData(int d)
{
	data =  d;
}

//getData -> getter
int Node::getData()
{
	return data;
}
