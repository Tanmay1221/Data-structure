#ifndef _CLINKEDLIST__H_
#define _CLINKEDLIST__H_
#include"Node.h"

class CLinkedList
{
	Node* head;
public:
	CLinkedList();
	~CLinkedList();
	CLinkedList(CLinkedList&);
	
	void Insert(int);
	void Append(int);
	int DeleteFirst();
	int DeleteLast();
	int DeleteByPos(int);
	void InsertByPos(int,int);	
	
};
#endif
