#include"DLinkedList.h"
#include"Node.h"

int main()
{
	DLinkedList l1;
	l1.Insert(10);
	l1.Insert(20);
	l1.Insert(30);
	//l1.DeleteFirst();
	//l1.Insert(40);
	//l1.Insert(50);
	l1.Append(60);
	l1.Display();
	l1.DeleteLast();
	//l1.Append(70);
	//l1.DeleteFirst();
	l1.Display();
	l1.InsertByPosition(3,1900);
	l1.Display();
	l1.DeleteByPosition(2);
	l1.Display();
}
