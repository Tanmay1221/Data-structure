#include"DLinkedList.h"
DLinkedList::DLinkedList()
{
	head = NULL;
	tail = NULL;
}

DLinkedList::~DLinkedList()
{

}

void DLinkedList::Insert(int d)
{
	Node *temp = new Node(d);
	if(head==NULL)
	{
		head=tail=temp;
		return;
	}
	temp->setNext(head);
	head->setPrev(temp);
	head = temp;
}

void DLinkedList::Append(int d)
{
	Node *temp = new Node(d);
	if(head==NULL)
	{
		head=tail=temp;
		return;
	}
	tail->setNext(temp);
	temp->setPrev(tail);
	tail = temp;
}

int DLinkedList::DeleteFirst()
{
	if(head==tail)
	{
		delete head;
		head=tail=NULL;
	}
	else
	{
		Node* temp = head;
		head = temp->getNext();
		head->setPrev(NULL);
		delete temp;
	}
}

int DLinkedList::DeleteLast()
{
	if(head==tail)
	{
		delete head;
		head=tail=NULL;
	}
	else
	{
		Node* it= tail->getPrev();
		tail->setPrev(NULL);
		it->setNext(NULL);
		delete tail;
		tail=it;
	}	
}

void DLinkedList::InsertByPosition(int pos,int d)
{
	Node *temp=new Node(d);
	int c=CountNodes();
	if(pos==1)
		Insert(d);
	if(pos==c-1)
		Append(d);
	if(pos<1 || pos>c)
		cout<<"Ur Not Eligible bro"<<endl;
	else
	{
		Node* it=head;
		for(int i=1;i<pos-1;i++)
		{
			it=it->getNext();
		}
		Node* itn=it->getNext();
		itn->setPrev(temp);
		temp->setNext(itn);
		it->setNext(temp);
		temp->setPrev(it);
	}


}

int DLinkedList::DeleteByPosition(int pos)
{
	
	int c=CountNodes();
	if(pos==1)
		DeleteFirst();
	if(pos==c)
		DeleteLast();
	if(pos<1 || pos>c)
		cout<<"Ur Not Eligible bro"<<endl;
	else
	{
		Node* it=head;
		for(int i=1;i<pos-1;i++)
		{
			it=it->getNext();
		}
		Node* temp=it->getNext();
		Node* itn=temp->getNext();
		it->setNext(temp->getNext());
		itn->setPrev(it);
		
	}



}

void DLinkedList::Display()
{
	if(head!=NULL)
	{
		Node *it = head;
		while(it->getNext()!=NULL)
		{
			cout<<it->getData()<<"=>";
			it=it->getNext();
		}
		cout<<it->getData()<<endl;
	}
	else
	{
		cout<<"DLL is empty"<<endl;
	}
}


int DLinkedList::CountNodes()
{
	int count=0;
	Node *it = head;
	while(it!=NULL)
		{
			count++;
			it=it->getNext();
		
		}
	return count;
}





