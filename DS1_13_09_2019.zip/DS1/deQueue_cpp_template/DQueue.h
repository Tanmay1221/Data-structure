#ifndef _DQUEUE__H_
#define _DQUEUE__H_
#include<iostream>
#include<cstdlib>
using namespace std;
template<class T>
class DQueue
{

	T *arr;
	int f=-1;
	int r=-1,size;

public:
	DQueue();
	~DQueue();
	void InsertFormF(T);
	int enterElement();
	void InsertFormR(T);
	T RemoveFormF();
	T RemoveFormR();
	int isFull();
	int isEmpty();
	void display();
};

#endif

