#include "LinkedList.h"
#include "Student.h"
#include<ostream>
using namespace std;
LinkedList::LinkedList()
{
	head=NULL;
}

LinkedList::LinkedList(Node* ptr)
{
	head = ptr;
}

LinkedList::~LinkedList()
{
	DeleteAll();
}

void LinkedList:: Insert(const Student data)
{
	Node *temp=new Node(data,head);
	
	head=temp;
}

void LinkedList:: Append(const Student data)
{
	Node *temp=new Node(data);
	if(head==NULL)
	{
		head=temp;
	}
	else
	{
		Node* it=head;
		while(it->getNext()!=NULL)
		{
			it=it->getNext();
		}
		it->setNext(temp);
		
	}

}

Student LinkedList:: deleteFirst()
{
	
	if(head!=NULL)
	{
		Node* it=head;
		head=it->getNext();
		delete it;
		
	}
	else
	{
		cout<<"LL is Empty";
	}
	
	

}

Student LinkedList:: deleteLast()
{
	if(head!=NULL)
	{
		Node* it=head;
		while(it->getNext()->getNext()!=NULL)
		{
			it=it->getNext();


		}
		Node* temp=it->getNext();
		it->setNext(NULL);
		delete temp;
	}


}

/*void LinkedList::display()
{
	if(head!=NULL)
	{
		Node *it=head;
		while(it->getNext()!=NULL)
		{
			cout<<it->getData()<<"-->>";
			it=it->getNext();
		}
		cout<<it->getData()<<endl;
			
	}

}
*/	


void LinkedList::InsertByPosition(int pos,Student data)
{
	int c=CountNodes();
	if(pos==1)
		Insert(data);
	if(pos==c)
		Append(data);
	if(pos<1 && pos>c)
		cout<<"U r very wrong person to handle this system"<<endl;
	else
	{
		Node* it=head;
		for(int i=1;i<pos-1;i++)
		{
			it=it->getNext();
		}
		Node* temp=new Node(data);	
		temp->setNext(it->getNext());
		it->setNext(temp);
	}
	
	
}
Student LinkedList::DeleteByPosition(int pos)
{
	int c=CountNodes();
	if(pos==1)
		deleteFirst();
	if(pos==c)
		deleteLast();
	if(pos<1 && pos>c)
		cout<<"U r very wrong person to handle this system"<<endl;
	else
	{
		Node* it=head;
		for(int i=1;i<pos-1;i++)
		{
			it=it->getNext();
		}
		Node* temp=it->getNext();
		it->setNext(temp->getNext());
		temp->setNext(NULL);
		delete temp;
	}
}

int LinkedList:: CountNodes()
{
	int count=0;
	Node *it=head;
	while(it!=NULL)
	{
		count++;
		it=it->getNext();
	}
	return count;
}


LinkedList::LinkedList(const LinkedList &x)
{
	Node *it=x.head;
	this->head=NULL;
	while(it!=NULL)
	{
		this->Append(it->getData());
		it=it->getNext();
	}	
	
}

void LinkedList::DeleteAll()
{
	Node *it=head;	
	while(it!=NULL)
	{
		Node* temp=it;
		it=it->getNext();
		delete temp;
	}
}

void LinkedList::operator=(LinkedList &x)
{
	this->DeleteAll();
	this->head = NULL;
	Node *it=x.head;
	while(it!=NULL)
	{
		this->Append(it->getData());
		it=it->getNext();
	}
	
}

ostream& operator<<(ostream& out, LinkedList& x)
{
	if(x.head!=NULL)
	{
		Node *it=x.head;
		while(it!=NULL)
		{
			out<<it->getData().getName()<<"->";
			out<<it->getData().getPNR()<<"  ";
			it=it->getNext();
		}
		out<<endl;
		//out<<it->getData();
			
	}
	return out;

}

void LinkedList::selectionSort()
{
	int c = CountNodes();
	if(head!=NULL)
	{	
		
		Node *it= head;
		while(it!=NULL)
		{
			Node *itn = it->getNext();
			while(itn!=NULL)
			{
				if(it->getData().getPNR() > itn->getData().getPNR())
				{
					Node* temp = new Node();
					temp->setData(it->getData());
					it->setData(itn->getData());
					itn->setData(temp->getData());
			}
			itn=itn->getNext();
		}
		it=it->getNext();
		}
	}
	
}

Student LinkedList::operator[](int pos)
{
	Node *it = head;
	for(int i=1;i<pos;i++,it=it->getNext());
	return it->getData();
}

void LinkedList::search_student(int prn)
{
	Node *it = head;
	while(it!=NULL)
	{
		if(prn == it->getData().getPNR())
		{
			cout<<it->getData().getName()<<"->";
			cout<<it->getData().getPNR()<<endl;
			return;		
		}
		else
			it = it->getNext();	
	}
	cout<<"record not found.."<<endl;
}

LinkedList LinkedList::operator+(const LinkedList& x)
{
	LinkedList temp;
	Node *it = this->head;
	while(it!= NULL)
	{
		temp.Append(it->getData());
		it = it->getNext();
	}
	it = x.head;
	while(it!= NULL)
	{
		temp.Append(it->getData());
		it = it->getNext();
	}
	return temp;
}
