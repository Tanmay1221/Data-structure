#ifndef _LINKEDLIST__H_
#define _LINKEDLIST__H_
#include<ostream>
using namespace std;
#include "Node.h"
#include"Student.h"

class LinkedList
{
	Node *head;
public:
	LinkedList();
	LinkedList(Node*);
	~LinkedList();
	void Insert(const Student);
	void Append(const Student);
	Student deleteFirst();
	Student deleteLast();
	void display();
	void InsertByPosition(int,const Student);
	Student DeleteByPosition(int);
	int CountNodes();
	LinkedList(const LinkedList &);
	void DeleteAll();
	void selectionSort();
	void operator=(LinkedList &x);
	Student operator[](int n);
	void search_student(int);
	friend ostream& operator<<(ostream& out, LinkedList& x);
	LinkedList operator+(const LinkedList& x);
};
#endif
