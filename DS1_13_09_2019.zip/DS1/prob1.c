#include<stdio.h>
int main()
{
	int n; // element in array
	int k;//lukky number
	int arr[100];
	int count=0;
	printf("Enter the number of element in array : ");
	scanf("%d",&n);
	printf("Enter lucky number : ");
	scanf("%d",&k);

	for(int i=0;i<n;i++)
	{
		scanf("%d",&arr[i]);
	}
	int temp;
	
	for(int i=0;i<n;i++)
	{
		for(int j=i;j<n;j++)
		{
			if(i!=j)
			{
				temp = arr[j] + arr[i];
				if(temp == k)
				{
					count++;
				}
			}
		} 
	}
printf("%d",count);
}
