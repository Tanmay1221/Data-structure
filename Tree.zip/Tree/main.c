#include<stdio.h>
#include<stdlib.h>

typedef struct Node
{
	struct Node* left;
	int data;
	struct Node* right;
}node;




node* search(node* root,int data)
{
	if(root==NULL || root->data==data)
		return root;

	if(data < root->data)
	     search(root->left,data);
	else
	     search(root->right,data);

}
int getMinValue(node* root)
{
	while(root->left)
		root=root->left;

	return root->data;
}



int getMaxValue(node* root)
{
	while(root->right)
		root=root->right;

	return root->data;
}


node* deletenode(node* root,int data)
{
	if(root==NULL)
		return root;
	else if(data < root->data)
	{
		root->left=deletenode(root->left,data);
	}
	else if(data >root->data)
	{
		root->right=deletenode(root->right,data);
	}
	else
	{
		if(root->left==NULL)//only right node is present
		{
			node* ret=root->right;
			free(root);
			return ret;
		}
		else if(root->right==NULL)//only left node is present
		{

			node* ret=root->left;
			free(root);
			return ret;
		}
		else		//both side node present
		{
			root->data=getMinValue(root->right);
			root->right=deletenode(root->right,root->data);
		}
	}
	return root;

}






void preorder(node* root)
{
	if(root !=NULL)
	{
	printf("%d--",root->data);
	preorder(root->left);
	preorder(root->right);
	}
}




void postorder(node* root)
{
	if(root !=NULL)
	{
	postorder(root->left);
	postorder(root->right);
	printf("%d--",root->data);	
	}
	
}

int main()
{

	node* root=NULL;
	root=insert(root,15);
	insert(root,10);
	insert(root,20);
	insert(root,18);
	insert(root,25);
	insert(root,22);	
	inorder(root);
	printf("\n");
	preorder(root);
	printf("\n");
	postorder(root);
	printf("\n");
	search(root ,10);
	node* t = search(root, 200);
	if(t)
		printf("%d",t->data);
	else
		printf("Not found\n");
	printf("%d--\n",getMinValue(root));
	printf("%d--\n",getMaxValue(root));
	deletenode(root,20);
	inorder(root);
	printf("\n");
	
return 0;	
}
