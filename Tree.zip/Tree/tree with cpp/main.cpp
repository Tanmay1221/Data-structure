#include<iostream>
using namespace std;
#include"Tree.h"
int main()
{
	Tree T;
	T.insert(10);
	T.insert(20);
	T.insert(9);
	T.insert(10);
	T.insert(30);
	T.inorder();
	Tree t1(T);
	cout<<endl;
	t1.inorder();
	cout<<endl;
	T.deletenode(10);
	T.inorder();

	//T.insert(20);

}
