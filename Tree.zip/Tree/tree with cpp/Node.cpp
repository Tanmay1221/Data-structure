#include"Node.h"
#include<iostream>
using namespace std;

Node::Node()
{
	data=0;
	left=NULL;
	right=NULL;
}
Node::Node(int x)
{
	data=x;
	left=NULL;
	right=NULL;
}
Node::Node(int x ,Node* l )
{
	data=x;
	left=l;
	right=NULL;
}
Node::Node(Node* r ,int x )
{
	data=x;
	left=NULL;
	right=r;
}

Node::Node(Node* l,int x,Node* r)
{
	
	data=x;
	left=l;
	right=r;
}
Node::~Node()
{

}

int Node::getdata()
{
	return data;
}

void Node::setdata(int x)
{
	data=x;
}

Node* Node::getleft()
{
	return left;
}

void Node::setleft(Node* x)
{
	left=x;
}

Node* Node::getright()
{
	return right;
}
void Node::setright(Node* x)
{
	right=x;
}
