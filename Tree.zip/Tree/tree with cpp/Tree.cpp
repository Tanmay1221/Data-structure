#include<iostream>
using namespace std;

#include"Tree.h"

Tree::Tree()
{
	root=NULL;
}

Tree::Tree(Tree& x )
{
	//t2---this
	//T-----x
	this->root=x.root;
	preo(root);
	
}

void Tree::preo(Node* root)
{
	if(root != NULL)
	{
	insert(root->getdata());
	preo(root->getleft());
	preo(root->getright());
	}
}	
Node* Tree::insert(int data)
{
	if(root==NULL)
		root=new Node(data);
	else
		root=insert(root,data);
		
}

Node* Tree::insert(Node* root,int data)
{	
	if(root==NULL)
	{
		Node* temp=new Node(data);
		return temp; 
	}
	else
	{	
		if( data < root->getdata() )
		{
			root->setleft(insert(root->getleft(),data));
		}
		else if(data > root->getdata())
		{
			root->setright(insert(root->getright(),data));
		}
	}
return root;


}

int Tree::getMinValue(Node* root)
{
	while(root->getleft())
		root=root->getleft();

	return root->getdata();
}


void Tree::deletenode(int data)
{
	deletenode(root, data);

}
Node* Tree::deletenode(Node* root,int data)
{
	if(root==NULL)
		return root;
	else if(data < root->getdata())
	{
		root->setleft(deletenode(root->getleft(),data));
	}
	else if(data >root->getdata())
	{
		root->setright(deletenode(root->getright(),data));
	}
	else
	{
		if(root->getleft()==NULL)//only right node is present
		{
			Node* ret=root->getright();
			free(root);
			return ret;
		}
		else if(root->getright()==NULL)//only left node is present
		{

			Node* ret=root->getleft();
			free(root);
			return ret;
		}
		else		//both side node present
		{
			root->setdata(getMinValue(root->getright()));
			root->setright(deletenode(root->getright(),root->getdata()));
		}
	}
	return root;

}



void Tree::inorder()
{	
	//cout<<"I am in inorder()";
	inorder(root);
}

void Tree::inorder(Node* root)
{
	//cout<<"I am in inorder(Node* root)";
	if(root != NULL)
	{
	inorder(root->getleft());
	cout<<root->getdata();
	inorder(root->getright());
	}
}




