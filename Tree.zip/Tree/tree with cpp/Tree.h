
#ifndef _TREE__H_
#define _TREE__H_

#include"Node.h"
class Tree
{
	Node* root;
public:
	Tree();
	Tree(Tree& );
	//void operator=(Tree& );
	Node* insert(int data);
	Node* insert( Node* ,int );
	void inorder();
	void inorder( Node* );
	void preo(Node* root);
	void deletenode(int );
	Node* deletenode(Node* ,int );
	int getMinValue(Node* );
		

};

#endif
