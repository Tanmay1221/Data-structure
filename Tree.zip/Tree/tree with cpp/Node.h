
#ifndef _NODE__H_
#define _NODE__H_


class Node
{
	int data;
	Node* left;
	Node* right;
public:
	Node();
	Node(int );
	Node(int ,Node* );
	Node(Node* ,int );
	Node(Node* ,int ,Node* );
	~Node();
	int getdata();
	void setdata(int );
	Node* getleft();
	void setleft(Node* );
	Node* getright();
	void setright(Node* );

};


#endif
