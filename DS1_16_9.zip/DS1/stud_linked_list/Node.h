#ifndef _NODE__H_
#define _NODE__H_
#include<iostream>
using namespace std;
#include"Student.h"

class Node
{
	Node *next;
	Student data;
public:
	Node(const Student);
	Node();
	Node(const Student,Node*);
	void setNext(Node* ptr);
	 Node* getNext();
	Student getData();
	void setData(const Student);
	

};
#endif
