#include "DQueue.h"
template<class T>
DQueue<T>::DQueue()
{
	cout<<"Enter Queue Size  :";
	cin>>size;
	arr=new T[size];

}

template<class T>
DQueue<T>::~DQueue()
{
	delete [] arr;
}

template<class T>
void DQueue<T>::InsertFormF(T data)
{

		if(!isFull())
		{
			if(f==-1)  //Empty queue
			{
				r++;
				f++;
				arr[f]=data;
				return;
			}	
	
			else if(!f==0)
			{
				f--;
				arr[f]=data;
			}

			else if(r<size-1)
			{
				r++;
				int i=r;
				while(f<=i)
				{
					arr[i]=arr[i-1];
					i--;
				}
				arr[f]=data;
			}	
			else
			{
				cout<<"oops......."<<endl;
			}
		
		}
		else
		{
			cout<<"bro no entry"<<endl;
		}


}

template<class T>
int DQueue<T>::enterElement()
{
	int n;
	cout<<"Enter Number ";
	cin>>n;
	return n;

}


template<class T>
void DQueue<T>::InsertFormR(T data)
{
	if(!isFull())
	{
		if(f==-1)  //Empty queue
		{
			r++;
			f++;
			arr[r]=data;
			return;
		}		
		
		else if(r<size)  // Inserting from rare end
		{
			r++;
			arr[r]=data;
			return;
		}

		else if(!f==0) // Queue empty from front side
		{
			f--;	
			int i=f;
			
			while(i<=r)
			{
				arr[i]=arr[i+1];
				i++;
			
			}
				arr[r]=data;
				return;

		}

		else
		{
			cout<<"OOOhhhh So Intelligent u R"<<endl;
		}

	}

	else
	{
		cout<<"Queue is Full "<<endl;
	}


}

template<class T>
T DQueue<T>::RemoveFormF()
{
	if(!isEmpty())
		{
			T temp=arr[f];
			if(f!=r)
				f++;
			else
			{
				f=-1;
				r=-1;
			}
		}
		else
		{
			cout<<"Queue is empty "<<endl;
		}

}

template<class T>
T DQueue<T>::RemoveFormR()
{

	if(!isEmpty())
	{
		T temp=arr[r];
		r--;
		return temp;		

	}
	else
	{
		cout<<"oohh my god queue is empty"<<endl;
	}


}


template<class T>
int DQueue<T>::isFull()
{
	if(f==0 && r==size-1)
		return 1;
	else
		return 0;

}


template<class T>
int DQueue<T>::isEmpty()
{
	if(f==-1)
		return 1;
	else
		return 0;

}

template<class T>
void DQueue<T>::display()
{
	if(!isEmpty())
	{
		int i=f;
		while(i<=r)
		{
			cout<<arr[i];
			i++;
		}
		cout<<endl;
	}
	else
	{
		cout<<"Queue is Empty"<<endl;
	}


}
