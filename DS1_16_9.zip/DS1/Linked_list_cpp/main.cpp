
#include<iostream>
using namespace std;
#include"LinkedList.h"
#include"Node.h"

int main()
{

	LinkedList l1;
	l1.insert(100);
//cout<<l1;
	l1.insert(21);
//cout<<l1;
//	l1.DeleteLast();
//cout<<l1;
	l1.insert(30);
//cout<<l1;
//	l1.DeleteFirst();
//cout<<l1;
	l1.insert(14);
//cout<<l1;
	l1.insert(15);
//cout<<l1;
	l1.insert(60);
//cout<<l1;
	l1.insert(170);
cout<<l1;
//	l1.DeleteLast();
//cout<<l1;
	LinkedList l2;	
	l2=l1;
cout<<l2;
	LinkedList l3(l2);
cout<<l3;
	//l3.DeleteByPos(2);
//cout<<l3;
	l3.selectionSort();
cout<<l3;
}
