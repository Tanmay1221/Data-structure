#ifndef _QUEUE__H_
#define _QUEUE__H_
#include<iostream>
#include<ostream>
using namespace std;

class Queue
{
	int *arr;
	int r;
	int f;
	int size;

public:
	Queue();
	~Queue();
	void enqueue(int );
	int dequeue();
	void display();
	friend ostream& operator<<(ostream& out , Queue& q);
	
};
#endif
