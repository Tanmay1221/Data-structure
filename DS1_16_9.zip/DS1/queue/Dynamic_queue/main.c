#include<stdio.h>
#include<stdlib.h>
int *arr;
int f=-1;
int r=-1;
int size;




void display()
{
	int i;
	if(f==-1)
	{
		printf("Queue is Empty\n");
	}
	else
	{	
		for(i=f;i<=r;i++)
		{
			printf("%d<--",arr[i]);
		}
		printf("\n");
	}
}

void enqueue(int data)
{
	if(r==size-1)
	{
		printf("Queue is Full\n");	
	}
	else
	{		
		if(f==-1)
		{
			f++;
		}
		r++;
		arr[r]=data;
		//display();	
	}
}

void dequeue()
{
	if(f==-1)
	{
		printf("Queue is Empty\n");
	}
	else
	{	
		int temp=arr[f];	
		f++;
		//printf("%d\n",f);
	}	
}

void init()
{
	printf("Enter total no of elements");
	scanf("%d",&size);
	arr=(int*)malloc(size * sizeof(int));
}

void fini()
{
	free(arr);
}


int main()
{
	
		
	init();	
	

	enqueue(10);
	enqueue(20);
	enqueue(30);
	enqueue(40);

	display();
	
	dequeue();
	display();

	dequeue();
	display();
	fini();
	return 0;

}
