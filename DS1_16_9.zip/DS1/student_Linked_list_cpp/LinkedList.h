#ifndef _LINKEDLIST__H_
#define _LINKEDLIST__H_
#include"Node.h"
class LinkedList
{
	Node* head;
public:
	LinkedList();
	~LinkedList();
	LinkedList(int);
	LinkedList(LinkedList&);
	void Insert(int);
	void append(int);
	void InsertByPosition(int,int);
	void DeleteFirst();
	void DeleteLast();
	void DeleteByPosition(int);
	void Display();	
	int getNumberOfNodes();
	
};
#endif
