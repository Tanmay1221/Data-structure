#include"linkedlist.h"
#include"node.h"
#include"Student.h"

int main()
{

	Linkedlist l1;	
	Student s("Ajinkya",123);
	l1.insert(s);
	l1.display();
}
