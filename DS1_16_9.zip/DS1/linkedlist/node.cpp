#include"node.h"
#include<iostream>
using namespace std;

Node::Node()
{
	next=NULL;
}
	

Node::Node(Student d)
{
	data=d;
	next=NULL;
}



Node::Node(Student d,Node* ptr)
{
	data=d;
	next=ptr;
}



Node::Node(Node& x)
{
	this->data=x.data;
	this->next=x.next;
}

void Node::operator=(Node& x)
{
	this->data=x.data;
	this->next=x.next;

}

Node::~Node()
{
	
}

Student Node::getData()
{
	return data;
}

void Node::setData(Student d)
{
	data=d;
}


Node* Node::getNext()
{
	return next;
}

void Node::setNext(Node* ptr)
{
	next=ptr;
}

