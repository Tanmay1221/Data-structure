#include"Student.h"
#include<stdlib.h>
#include<cstring>
Student::Student()
{
	name = new char[100];
	strcpy(name,"Chota_Don");
	prn = 1235;
}

Student::~Student()
{

}

Student::Student(char* n)
{
	name = new char[strlen(n)+1];
	strcpy(name,n);
}

Student::Student(char* n ,int p)
{
	name = new char[strlen(n)+1];
	strcpy(name,n);
	prn = p;	
}

Student::Student(const Student& x)
{
	this->name = new char[strlen(x.name)+1];
	strcpy(this->name,x.name);
	this->prn = x.prn;	
}

void Student::operator=(Student& x)
{
	this->name = new char[strlen(x.name)+1];
	this->prn = x.prn;
}

