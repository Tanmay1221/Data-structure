#ifndef _STUDENT_H_
#define _STUDENT_H_
class Student
{
	char *name;
	int prn;
public:
	Student();
	~Student();
	Student(char*);
	Student(char*,int);
	Student(const Student&);
	void operator=(Student&);
	char* getName(){ return name; }
	void setName(char* n){ name = n; }
	int getPrn(){ return prn; }
	void setPrn(int p){ prn = p;  }
};
#endif
