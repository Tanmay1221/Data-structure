#ifndef _node_H_
#define _node_H_
#include"Student.h"

class Node
{
	Student data;
	Node *next;
public:
	Node();	
	Node(Student);
	Node(Student,Node*);
	Node(Node&);
	void operator=(Node&);
	~Node();
	Student getData();
	void setData(Student);
	
	Node* getNext();
	void setNext(Node*);

};
#endif
