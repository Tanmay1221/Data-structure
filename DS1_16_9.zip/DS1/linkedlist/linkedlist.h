#ifndef _linkedlist_H_
#define _linkedlist_H_
#include"node.h"
class Linkedlist
{
	Node *head;
	public:
	       Linkedlist();
	       ~Linkedlist();
	       Linkedlist(const Linkedlist &);
	       void operator=(const Linkedlist&);
	       void insert(const Student);
	       void append(const Student);
	       void deletefirst();
	       void deletelast();
	       void insertatpos(int,const Student);
	       void deleteatpos(int);
	       void display();
	       int NoOfNodes();
		


};
#endif
