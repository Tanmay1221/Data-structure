#include"linkedlist.h"
#include<iostream>
using namespace std;

Linkedlist::Linkedlist()
{
	head=NULL;
}
Linkedlist::~Linkedlist()
{

}
Linkedlist::Linkedlist(const Linkedlist &x)
{
	this->head = NULL;
	Node *it = x.head;
	while(it!=NULL)
	{
		this->append(it->getData());
	}
}
void Linkedlist::operator=(const Linkedlist& x)
{
	this->head = NULL;
	Node *it = x.head;
	while(it!=NULL)
	{
		this->append(it->getData());
	}
}

int Linkedlist::NoOfNodes()
{
	int count=0;
	Node *it=head;
	while(it!=NULL)
	{
		count++;
		it=it->getNext();
	}
return count;
}

void Linkedlist:: insert(const Student data)
{
	Node *tmp=new Node(data,head);
	head=tmp;
}
void Linkedlist::append(const Student data)
{
	if(head==NULL)
	{
		insert(data);
			

	}
	else
	{
	Node *tmp=new Node(data);
	Node *it=head;
	while(it->getNext()!=NULL)
	{
		it=it->getNext();
	}
	 it->setNext(tmp);
	}
}

void Linkedlist:: deletefirst()
{
	if(head!=NULL)
	{
		Node *tmp = head;
		head = tmp->getNext();
		delete tmp;
	}
	else
	{
		cout<<"LL is empty"<<endl;
	}
}

void Linkedlist::deletelast()
{
	if(head!=NULL)
	{
		Node *it = head;
		if(it->getNext()==NULL)
			head = NULL;
		while(it->getNext()->getNext() != NULL)
		{
			it=it->getNext();
		}
		Node* tmp = it->getNext();
		it->setNext(NULL);
		delete tmp;
	}
	else
	{
		cout<<"LL is empty"<<endl;
	}
}

void Linkedlist::insertatpos(int pos,const Student data)
{
	int c = NoOfNodes();
	Node *it = head;
	if(pos==0)
	{
		insert(data);
	}
	else if(pos==c+1)
	{
		append(data);
	}
	else if(pos<1 && pos>c)
	{
		cout<<"Dont use this system !!!"<<endl;
	}
	else
	{
		for(int i=1;i<pos-1;i++,it=it->getNext());
		Node *tmp = new Node(data);
		tmp->setNext(it->getNext());
		it->setNext(tmp);
	}
}

void Linkedlist::deleteatpos(int)
{
}


void Linkedlist::display()
{
 	if(head!=NULL)
	{
		Node *it=head;
		while(it!=NULL)
		{
		 cout<<it->getData().getName()<<"->";
		cout<<it->getData().getPrn()<<"->";	
		 it=it->getNext();
		}
	}
}


