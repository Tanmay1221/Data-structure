#ifndef _Student__H_
#define _Student__H_
#include<iostream>
#include<ostream>
#include<cstring>
#include<istream>
using namespace std;
class Student
{
	char *name;
	int pnr;
public:
	Student();
	Student(const char*,int);
	~Student();
	Student(const Student&);
	//void operator>(Student&);
	
	char* getName(){return name;}
	void setName(char* n){strcpy(name,n);}
	int getPNR(){ return pnr;}
	void setPNR(int p){ pnr = p; }
	
	friend ostream& operator<<(ostream& out,const Student& x);
	friend istream& operator>>(istream& in,Student& x);
};
#endif
