#include "LinkedList.h"
#include "Student.h"
#include<ostream>
using namespace std;

template<class T>
LinkedList<T>::LinkedList()
{
	head=NULL;
}

template<class T>
LinkedList<T>::LinkedList(Node<T>* ptr)
{
	head = ptr;
}

template<class T>
LinkedList<T>::~LinkedList()
{
	DeleteAll();
}

template<class T>
void LinkedList<T>:: Insert(const T data)
{
	Node<T> *temp=new Node<T>(data,head);
	
	head=temp;
}

template<class T>
void LinkedList<T>::Append(const T data)
{
	Node<T>* temp=new Node<T>(data);
	if(head==NULL)
	{
		head=temp;
	}
	else
	{
		Node<T>* it=head;
		while(it->getNext()!=NULL)
		{
			it=it->getNext();
		}
		it->setNext(temp);
		
	}

}

template<class T>
T LinkedList<T>::deleteFirst()
{
	
	if(head!=NULL)
	{
		Node<T>* it=head;
		head=it->getNext();
		delete it;
		
	}
	else
	{
		cout<<"LL is Empty";
	}
	
	

}

template<class T>
T LinkedList<T>::deleteLast()
{
	if(head!=NULL)
	{
		Node<T>* it=head;
		while(it->getNext()->getNext()!=NULL)
		{
			it=it->getNext();


		}
		Node<T>* temp=it->getNext();
		it->setNext(NULL);
		delete temp;
	}


}

/*void LinkedList::display()
{
	if(head!=NULL)
	{
		Node *it=head;
		while(it->getNext()!=NULL)
		{
			cout<<it->getData()<<"-->>";
			it=it->getNext();
		}
		cout<<it->getData()<<endl;
			
	}

}
*/	

template<class T>
void LinkedList<T>::InsertByPosition(int pos,T data)
{
	int c=CountNodes();
	if(pos==1)
		Insert(data);
	if(pos==c)
		Append(data);
	if(pos<1 && pos>c)
		cout<<"U r very wrong person to handle this system"<<endl;
	else
	{
		Node<T>* it=head;
		for(int i=1;i<pos-1;i++)
		{
			it=it->getNext();
		}
		Node<T>* temp=new Node<T>(data);	
		temp->setNext(it->getNext());
		it->setNext(temp);
	}
	
	
}

template<class T>
T LinkedList<T>::DeleteByPosition(int pos)
{
	int c=CountNodes();
	if(pos==1)
		deleteFirst();
	if(pos==c)
		deleteLast();
	if(pos<1 && pos>c)
		cout<<"U r very wrong person to handle this system"<<endl;
	else
	{
		Node<T>* it=head;
		for(int i=1;i<pos-1;i++)
		{
			it=it->getNext();
		}
		Node<T>* temp=it->getNext();
		it->setNext(temp->getNext());
		temp->setNext(NULL);
		delete temp;
	}
}

template<class T>
int LinkedList<T>::CountNodes()
{
	int count=0;
	Node<T>* it=head;
	while(it!=NULL)
	{
		count++;
		it=it->getNext();
	}
	return count;
}

template<class T>
LinkedList<T>::LinkedList(const LinkedList<T> &x)
{
	Node<T>* it=x.head;
	this->head=NULL;
	while(it!=NULL)
	{
		this->Append(it->getData());
		it=it->getNext();
	}	
	
}

template<class T>
void LinkedList<T>::DeleteAll()
{
	Node<T>* it=head;	
	while(it!=NULL)
	{
		Node<T>* temp=it;
		it=it->getNext();
		delete temp;
	}
}

template<class T>
void LinkedList<T>::operator=(LinkedList<T> &x)
{
	this->DeleteAll();
	this->head = NULL;
	Node<T>* it=x.head;
	while(it!=NULL)
	{
		this->Append(it->getData());
		it=it->getNext();
	}
	
}

template<class T>
ostream& operator<<(ostream& out, LinkedList<T>& x)
{
	if(x.head!=NULL)
	{
		Node<T>* it=x.head;
		while(it!=NULL)
		{
			out<<it->getData().getName()<<"->";
			out<<it->getData().getPNR()<<"  ";
			it=it->getNext();
		}
		out<<endl;
		//out<<it->getData();
			
	}
	return out;

}

template<class T>
void LinkedList<T>::selectionSort()
{
	int c = CountNodes();
	if(head!=NULL)
	{	
		
		Node<T>* it= head;
		while(it!=NULL)
		{
			Node<T>* itn = it->getNext();
			while(itn!=NULL)
			{
				if(it->getData().getPNR() > itn->getData().getPNR())
				{
					Node<T>* temp = new Node<T>();
					temp->setData(it->getData());
					it->setData(itn->getData());
					itn->setData(temp->getData());
			}
			itn=itn->getNext();
		}
		it=it->getNext();
		}
	}
	
}

template<class T>
T LinkedList<T>::operator[](int pos)
{
	Node<T>* it = head;
	for(int i=1;i<pos;i++,it=it->getNext());
	return it->getData();
}

template<class T>
void LinkedList<T>::search_student(int prn)
{
	Node<T>* it = head;
	while(it!=NULL)
	{
		if(prn == it->getData().getPNR())
		{
			cout<<it->getData().getName()<<"->";
			cout<<it->getData().getPNR()<<endl;
			return;		
		}
		else
			it = it->getNext();	
	}
	cout<<"record not found.."<<endl;
}

template<class T>
LinkedList<T> LinkedList<T>::operator+(const LinkedList<T>& x)
{
	LinkedList temp;
	Node<T>* it = this->head;
	while(it!= NULL)
	{
		temp.Append(it->getData());
		it = it->getNext();
	}
	it = x.head;
	while(it!= NULL)
	{
		temp.Append(it->getData());
		it = it->getNext();
	}
	return temp;
}
