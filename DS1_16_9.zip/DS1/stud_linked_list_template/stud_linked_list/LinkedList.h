#ifndef _LINKEDLIST__H_
#define _LINKEDLIST__H_
#include<ostream>
using namespace std;
#include "Node.h"
#include"Student.h"

template<class T>
class LinkedList
{
	Node<T>* head;
public:
	LinkedList();
	LinkedList(Node<T>*);
	~LinkedList();
	void Insert(const T);
	void Append(const T);
	T deleteFirst();
	T deleteLast();
	void display();
	void InsertByPosition(int,const T);
	T DeleteByPosition(int);
	int CountNodes();
	LinkedList(const LinkedList &);
	void DeleteAll();
	void selectionSort();
	void operator=(LinkedList &x);
	T operator[](int n);
	void search_student(int);
	template<class U>
	friend ostream& operator<<(ostream& out, LinkedList<U>& x);
	LinkedList operator+(const LinkedList& x);
};
#endif
