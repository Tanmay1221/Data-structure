#include "Node.h"
#include<cstring>
template<class T>
Node<T>::Node(const T x)
{
	data=x;
	next=NULL;
}

template<class T>
Node<T>::Node()
{
	next=NULL;
}

template<class T>
Node<T>::Node(const T x,Node<T>* ptr)
{
	data=x;
	next=ptr;
	
}

template<class T>
void Node<T>::setNext(Node<T>* ptr)
{
	next=ptr;
	
}

template<class T>
Node<T>* Node<T>::getNext()
{
	return next;
}
template<class T>
void Node<T>:: setData(const T x)
{
	data=x;
}
template<class T>
T Node<T>::getData()
{
	return data;
}




