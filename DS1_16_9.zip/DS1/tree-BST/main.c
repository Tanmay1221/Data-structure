#include<stdio.h>
#include<stdlib.h>
typedef struct _Node
{
	struct _Node* left;
	int data;
	struct _Node* right;
	


}Node;


int EnterNumber()
{	
	int n;
	printf("Enter Number Which U want To Insert  :");
	scanf("%d",&n);
	return n;

}

Node* Insert(Node* root,int data)
{
	if(root == NULL)
	{
		Node* tmp=(Node*)malloc(sizeof(Node));
		tmp->left=NULL;
		tmp->data=data;
		tmp->right=NULL;
		return tmp;
	}

	else
	{
		if(data > root->data)
		{
			root->right=Insert(root->right,data);

		}
		else if(data < root->data)
		{
			root->left=Insert(root->left,data);

		}

	}
	return root;

}


void InOrder(Node* root)
{
	if(root!=NULL)
	{
	InOrder(root->left);
	printf("%d--> \n",root->data);
	InOrder(root->right);
	}
}

void PreOrder(Node* root)
{
	if(root!=NULL)
	{
	printf("%d--> \n",root->data);
	PreOrder(root->left);
	PreOrder(root->right);
	}
}


void PostOrder(Node* root)
{
	if(root!=NULL)
	{
	PostOrder(root->left);	
	PostOrder(root->right);
	printf("%d--> \n",root->data);
	}
	
}

Node* Search(Node* root,int data)
{
	//if(root!=NULL)
	//{
		//if(root->data==data)
		if(root==NULL || root->data==data)
		{
			return root;
		}
		else if(data > root->data)
		{
			Search(root->right,data);
		}
		else if(data < root->data)
		{
			Search(root->left,data);
		}
	//return root;
	//}
	//else
		//printf("Not Found");
}





int MinValue(Node* root)
{
	while(root->left)
		root=root->left;
	//return root->data;
	printf("%d \n",root->data);

}

int MaxValue(Node* root)
{
	while(root->right)
		root=root->right;
	//return root->data;
	printf("%d \n",root->data);
}


Node* delete(Node* root , int data)
{
	if(root==NULL)
		return NULL;
	else if(data < root->data)
		root->left=delete(root->left,data);
	else if(data > root->data)
		root->right=delete(root->right,data);
	else
	{
		if(root->left==NULL)
		{
			Node* del=root->right;
			free(root);
			return del;
		}
		else if(root->right==NULL)
		{
			Node* del=root->left;
			free(root);
			return del;
		}
		else
		{
			root->data=MinValue(root->right);
			root->right=delete(root->right,root->data);
		}
	}
} 



int main()
{
Node* root=NULL;



while(1)
{
	int ch;
	printf("😋===========Menu Card==================😋\n");
	printf("👉1. Insert Element \n");
	printf("👉2. Delete Element \n");
	printf("👉3. Search Elements \n");
	printf("👉4. Find Minimum of Given Tree \n");
	printf("👉5. Find Maximum of Given Tree \n");
	printf("👉6. Inorder of Elements\n");
	printf("👉7. PreOrder of Elements \n");
	printf("👉8. PostOrder of Elements \n");
	printf("👉9. Exit \n");

	printf("=============================================\n");

	printf("Number Taka Please :");
	scanf("%d",&ch);
	switch(ch)
	{
		case 1:
			root=Insert(root,EnterNumber());
			break;
		case 2:delete(root,EnterNumber());
			break;
		case 3:	Search(root,EnterNumber());
			break;
		case 4: MinValue(root);
			break;
		case 5: MaxValue(root);
			break;
		case 6: InOrder(root);
			break;
		case 7: PreOrder(root);
			break;
		case 8: PostOrder(root);
			break;
		case 9:return(0);
			break;
		default:printf("\n Go to HEll  \n");
			break;

	}

}







/*
//root=Insert(root,12);
//Insert(root,24);
Insert(root,6);
Insert(root,2);
Insert(root,7);
Insert(root,10);
Insert(root,9);
Insert(root,270);
Insert(root,277);
Insert(root,198);

InOrder(root);
printf("\n");
PreOrder(root);
printf("\n");
PostOrder(root);
printf("\n");

printf("Min Value of Tree : %d \n",MinValue(root));
printf("Max Value of Tree : %d \n",MaxValue(root));

Node* t1=Search(root,676);
if(t1)
	printf("  Mil Hee Gaya==>%d \n ",t1->data);
else
	printf("Element Not Found 404 Error.......\n");
delete(root,270);
InOrder(root);*/
printf("\n");
return 0;
}
