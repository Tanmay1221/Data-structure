#include "LinkedList.h"
#include "Node.h"
#include"Student.h"
#include<iostream>
using namespace std;

int main()
{
	LinkedList l1;	
	Student s("tanmay",1234);	
	Student s1("Rohit",4567);
	Student s2("Ajinkya",3546);
	Student s3("D",2546);
	
	l1.Append(s);
	l1.Append(s1);
	l1.Append(s2);
	l1.Append(s3);	
	
	cout<<l1<<endl;
	
	l1.selectionSort();	
	cout<<l1<<endl;	
	
	cout<<"Your data --> "<<l1[3]<<endl;
	
	l1.search_student(4567);
	
	
	LinkedList l2;	
	Student s4("abc",12341);	
	Student s5("def",45672);
	Student s6("ghi",35463);
	Student s7("JKL",25464);
	
	l2.Append(s4);
	l2.Append(s5);
	l2.Append(s6);
	l2.Append(s7);	
	LinkedList l3=l1+l2;	
	cout<<l3;
}
