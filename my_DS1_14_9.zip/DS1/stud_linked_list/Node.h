#ifndef _NODE__H_
#define _NODE__H_
#include<iostream>
using namespace std;
#include"Student.h"
template<class T>
class Node
{
	Node<T> *next;
	T data;
public:
	Node(const T);
	Node();
	Node(const T,Node<T>*);
	void setNext(Node<T>* ptr);
	 Node* getNext();
	T getData();
	void setData(const T);
	

};
#endif
