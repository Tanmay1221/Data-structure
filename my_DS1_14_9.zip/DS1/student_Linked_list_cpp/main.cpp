#include"LinkedList.h"
#include"Node.h"

int main()
{

	LinkedList l1;
	l1.Insert(10);
	l1.Insert(20);
	l1.Insert(30);
//l1.Display();
	//l1.getNumberOfNodes();
	l1.DeleteFirst();
	l1.Insert(40);
	l1.Insert(50);
	l1.append(60);
	l1.append(70);
	l1.DeleteLast();
//l1.Display();
	//l1.getNumberOfNodes();
	l1.DeleteFirst();
	l1.DeleteFirst();
	//l1.Display();
	l1.getNumberOfNodes();
	l1.DeleteByPosition(2);
	l1.InsertByPosition(2,100);
	l1.Display();
	
	//LinkedList l2(l1);
	LinkedList l2;
	int i=1000000;
	while(i--)
		l2.append(i);
	l2.Display();
}
