#ifndef _NODE__H_
#define _NODE__H_

class Node
{
	int data;
	Node *Next;
public:
	Node();
	~Node();
	Node(int);
	Node(int,Node*);
	Node* getNext();
	void setNext(Node*);
	int getData();
	void setData(int);
};
#endif
