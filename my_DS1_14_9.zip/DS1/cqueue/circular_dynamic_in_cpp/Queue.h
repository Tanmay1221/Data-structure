#ifndef _QUEUE__H_
#define _QUEUE__H_

class Queue
{

	int f;
	int r;
	int *arr;
	int size;

public:
	Queue();
	~Queue();
	void enqueue(int);
	int dequeue();
	void display();



};
#endif
