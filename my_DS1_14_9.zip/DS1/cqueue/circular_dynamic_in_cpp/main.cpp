
#include "Queue.h"


								
int main()
{
	Queue q;

	q.enqueue(10);
	q.enqueue(120);
	q.enqueue(100);
	q.enqueue(101);
	q.display();
	
	q.dequeue();
	q.display();



return 0;
}
