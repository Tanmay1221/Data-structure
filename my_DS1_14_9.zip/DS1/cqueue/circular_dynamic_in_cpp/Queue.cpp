#include<iostream>
using namespace std;
#include"Queue.h"
#include<stdlib.h>


Queue::Queue()
{
	r=-1;
	f=-1;

	cout<<"Queue size : "<<endl;
	scanf("%d",&size);
	arr=new int[size*sizeof(int)];
}



Queue::~Queue()
{
	
	delete [] arr; 
}

	void Queue::enqueue(int x)
{
	
	if((f==r+1 )||(f==0 && r==size-1)) // first condition : check that front is awailable on next	
										//position
										//second condition : border condition
										
	{
		cout<<" Queue is Full"<<endl;
	
	}	
	else
	{	
		if(f==-1)
		{
			f=0;
		}
		if(r==size-1)
			r=0;
		else
			r++;
		arr[r]=x;
	}
}
	
int Queue::dequeue()
{

	int temp;
	if(r==-1 )
	{
		cout<<"Queue is Empty:"<<endl;
	}
	
	else
	{
		temp=arr[f];

		if(r==f) //checking last element in queue
		{		
			f=r=-1;
		}
		else
		{
			if(f==size-1)
			{		
				f=0;
			}
			else
			{
				f++;
			}	
		}
		return temp;	
	}
}


void Queue::display()
{
	int temp;
	if(r==-1) //cheack whether rear or front = -1 i.e queue is empty
	{
		cout<<"Queue is Empty:"<<endl;
	}
	
	else	
	{
		int i=f;
		
		while(i!=r) // itirate through loop until front is not equal to rear
		{
				cout<<arr[i]<<" , ";
				
				if(i==size-1) // check if we hit last position of queue.
				{
						i=0;  // if last then move front to 0th location of 												queue
				}	
				else
				{
							i++; // else increment front by one
				}	
		}
		cout<<arr[i]<<endl;
	}
}
