#include<stdio.h>
#include<stdlib.h>



int *arr;
int size;
int f=-1,r=-1;	

void init()
{
	printf("Queue size : ");
	scanf("%d",&size);

	arr = (int*)malloc(size*sizeof(int));
}


void fini()
{
	free(arr);
}


void display()
{
	int temp;
	if(r==-1) //cheack whether rear or front = -1 i.e queue is empty
	{
		printf("Queue is Empty:");
	}
	
	else	
	{
		int i=f;
		
		while(i!=r) // itirate through loop until front is not equal to rear
		{
				printf("%d ",arr[i]);
				
				if(i==size-1) // check if we hit last position of queue.
				{
						i=0;  // if last then move front to 0th location of queue
				}	
				else
				{
							i++; // else increment front by one
				}	
		}
		printf("\n");
	}

}


void enqueue(int x)
{

	if((f==r+1 )||(f==0 && r==size-1)) // first condition : check that front is awailable on next	
										//position
										//second condition : border condition
										
	{
		printf(" Queue is Full\n");
	
	}	
	else
	{	
		if(f==-1)
		{
			f=0;
		}
		if(r==size-1)
			r=0;
		else
			r++;
		arr[r]=x;
	}
}


int dequeue()
{
/*
step 1 : check empty??
remove element from queue
step 2 : check last element??
step 3 : check border condition.
*/
	int temp;
	if(r==-1 )  //rear is -1 then empty
	{
		printf("Queue is Empty:");
	}
	
	else
	{
		temp=arr[f];

		if(r==f) //checking last element in queue
		{		
			f=r=-1;
		}
		else
		{
			if(f==size-1)
			{		
				f=0;
			}
			else
			{
				f++;
			}	
		}
		return temp;	
	}
}
int main()
{
	init();
	enqueue(10);
	enqueue(20);
	enqueue(30);
	enqueue(60);
	enqueue(40);
	

	display();
	
	dequeue();
	dequeue();
	dequeue();
	
	enqueue(40);
	enqueue(50);
	enqueue(50);
	enqueue(50);

	display();

	fini();
return 0;
}
