#include<stdio.h>
#define SIZE 10

	int arr[SIZE];
	int f=-1;
	int r=-1;

int isFull()
{
	if((f==r+1)  || (f==0 && r==SIZE  -1))
	
		return 1;
	else
		return 0;
}

int isEmpty()
{
	if(f==-1)
		return 1;
	else
		return 0;
}


void display()
{

	if(isEmpty())
	{
		printf("Queue is Empty");		
	}
	else
	{
		for(int i=f;i<=r;i++)
		{
			printf("%d==>>",arr[i]);	
		}
		printf("\n");		
	}
}


void enqueue(int data)
{
	if(isFull())
	{
		printf("Queue is full");
	}
	else
	{
		if(f==-1)
		{	
			f++;
		}
		
			r=(r+1)%SIZE;
			arr[r]=data;

		
	}


}

void dequeue()
{
	
	if(isEmpty())
	{
		printf("Queue is Empty");		
	}
	else
	{
		int temp=arr[f];
		f++;
	}


}





int main()
{

	enqueue(10);
	enqueue(20);
	enqueue(30);

	display();
	
	dequeue();		
	display();
}
